@extends('layouts.coordinador')
@section('coord-content')
  soy el coordinador
@stop
