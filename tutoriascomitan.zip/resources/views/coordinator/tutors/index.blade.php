@extends('layouts.coordinador')
@section('coord-content')
 @include('shared.coord-hod.tutors.index') 
 @include('shared.session-status')
@endsection
