@extends('layouts.coordinador')
@section('coord-content')
	@include('shared.coord-hod.students.index')
	@include('shared.session-status')
@endsection
