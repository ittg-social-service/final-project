@extends('layouts.coordinador')
@section('coord-content')
	@include('shared.coord-hod.students.create')
@endsection
