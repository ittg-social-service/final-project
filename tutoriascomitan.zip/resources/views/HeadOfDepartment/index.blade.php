@extends('layouts.jefe')
@section('jefe-content')
    <div class="row">
      <div class="col s12">
        <p class="blue-text">
          Datos actualizados.
        </p>
      </div>
    </div>
@endsection
