@extends('layouts.jefe')
@section('jefe-content')
	@include('shared.coord-hod.students.index')
	@include('shared.session-status')
@endsection
