@extends('layouts.jefe')
@section('jefe-content')
	@include('shared.coord-hod.students.create')
@endsection
