<li><a  href="{{ url('/coordinador/alumnos') }}"><i class="material-icons">school</i>ALumnos</a></li>
<li><a  href="{{ url('/coordinador/tutores') }}"><i class="material-icons">people</i>Tutores</a></li>
<li><a  href="{{ url('/coordinador/grupos') }}"><i class="material-icons">group_work</i>Grupos</a></li>
<li><a  href="{{ url('/coordinador/asignaciones') }}"><i class="material-icons">assignment_ind</i>Asignar</a></li>
<li><a  href="{{ url('/coordinador/perfil') }}"><i class="material-icons">build</i>Perfil</a></li>
@if (Auth::user()->hasRole('tutor'))
	
	<li><a  href="{{ url('/teacher/groups') }}"><i class="material-icons">autorenew</i>Ingresar como tutor</a></li>
@endif