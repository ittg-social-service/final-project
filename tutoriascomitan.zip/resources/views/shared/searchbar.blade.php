<div class="">
  <nav>
    <div class="nav-wrapper  white">
      <form>
        	<div class="input-field">
          	<input id="search" type="search" required ng-model="searchTarget" placeholder="Buscar">
          	<label for="search"><i class="material-icons ">search</i></label>
          	<i class="material-icons">close</i>
        	</div>
      </form>
    </div>
  </nav>
</div>
