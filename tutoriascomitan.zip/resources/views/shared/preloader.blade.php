<div class="progress" ng-show="vm.dataLoading">
	<div class="indeterminate"></div>
</div>