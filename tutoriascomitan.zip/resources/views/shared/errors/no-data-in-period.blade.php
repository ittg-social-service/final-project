<div ng-show="vm.groups.length <= 0" >
	<div class="row">
	 	<div class="col m12 s12 grey lighten-3">
	 		<h5 class="center-align">No existen grupos en este periodo</h5>
	 	</div>
	</div>
</div>